#!/bin/bash
set -e

echo "Создание резервной копии данных..."

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="backups"
BACKUP_FILE="backup_${TIMESTAMP}.tar.gz"

# Создаем директорию для бэкапов если её нет
mkdir -p $BACKUP_DIR

# Останавливаем приложение для консистентности бэкапа
docker-compose stop

# Копируем данные
docker run --rm \
  -v nexuspm_app_data:/source \
  -v $(pwd)/$BACKUP_DIR:/backup \
  alpine tar -czf /backup/$BACKUP_FILE -C /source ./

# Запускаем приложение обратно
docker-compose start

echo "Резервная копия создана: $BACKUP_DIR/$BACKUP_FILE"
echo "Для восстановления используйте интерфейс приложения или скопируйте файлы в volumes"