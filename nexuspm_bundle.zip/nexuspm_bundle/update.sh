#!/bin/bash
set -e

echo "Обновление Task Management System..."

# Останавливаем старые контейнеры
docker-compose down

# Удаляем старые образы (опционально, для экономии места)
docker image prune -f

# Загружаем последние версии образов
docker-compose pull

# Запускаем обновленное приложение
docker-compose up -d

echo "Обновление завершено"
echo "Приложение доступно по: http://localhost:80"